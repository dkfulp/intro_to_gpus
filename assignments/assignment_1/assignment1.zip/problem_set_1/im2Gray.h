#ifndef IM2_GRAY_H_
#define IM2_GRAY_H_

#include "utils.h"


void launch_im2gray(uchar4* d_rgba, unsigned char *d_grey, size_t numRows, size_t numCols);



#endif